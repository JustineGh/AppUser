var express = require('express');
var router = express.Router();
var nodeMailer = require('nodemailer');

router.post('/home', function (req, res) {
  let transporter = nodeMailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: {
          user: 'justine@cedrus.digital',
          pass: 'jossy1231'
      }
  });
  let mailOptions = {
      from: '"Justine Ghosn" <xx@gmail.com>', // sender address
      to: req.body.to, // list of receivers
      subject: req.body.subject, // Subject line
      text: req.body.body, // plain text body
      html: '<b>'+req.body.body +'</b>' // html body
  };

  transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
          return console.log(error);
      }
      console.log('Message %s sent: %s', info.messageId, info.response);
          res.render('index', { title: 'Cedrus' });
      });
  });

module.exports = router;
